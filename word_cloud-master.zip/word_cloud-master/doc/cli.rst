.. _wordcloud_cli:

Command Line Interface
======================

.. argparse::
   :module: wordcloud.wordcloud_cli
   :func: make_parser
   :prog: wordcloud_cli
