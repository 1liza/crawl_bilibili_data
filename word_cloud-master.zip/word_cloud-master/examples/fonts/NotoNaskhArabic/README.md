The font file was downloaded from: https://www.google.com/get/noto/#naskh-arab
